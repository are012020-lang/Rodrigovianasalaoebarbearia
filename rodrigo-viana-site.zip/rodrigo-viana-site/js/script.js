const $=(s,c=document)=>c.querySelector(s),$$=(s,c=document)=>[...c.querySelectorAll(s)];
addEventListener('load',()=>setTimeout(()=>$('#loader').classList.add('off'),500));
const hd=$('#hd'),nav=$('#nav'),bg=$('#bg');
addEventListener('scroll',()=>hd.classList.toggle('sc',scrollY>40),{passive:true});
bg.onclick=()=>{const o=nav.classList.toggle('open');bg.setAttribute('aria-expanded',o)};
$$('#nav a').forEach(a=>a.onclick=()=>{nav.classList.remove('open');bg.setAttribute('aria-expanded',false)});
const io=new IntersectionObserver(e=>e.forEach(x=>x.isIntersecting&&(x.target.classList.add('in'),io.unobserve(x.target))),{threshold:.15});
$$('section:not(.hero) h2,.tx,.ph,.sc,.pi,.cmp').forEach(e=>{e.classList.add('rv');io.observe(e)});
// before/after (uses one side-by-side photo)
$$('.cmp').forEach(c=>{const s=c.dataset.img;c.innerHTML=`<img src="${s}" alt="" style="visibility:hidden;width:200%;max-width:none" hidden><div class="a" style="background-image:url(${s})"></div><div class="d" style="background-image:url(${s})"></div><i></i><b class="l1">Antes</b><b class="l2">Depois</b>`;
 c.style.aspectRatio='277/554';const d=$('.d',c),l=$('i',c);let on=0;
 const mv=x=>{const r=c.getBoundingClientRect(),p=Math.max(0,Math.min(100,(x-r.left)/r.width*100));d.style.clipPath=`inset(0 0 0 ${p}%)`;l.style.left=p+'%'};
 c.onpointerdown=e=>{on=1;mv(e.clientX)};addEventListener('pointerup',()=>on=0);addEventListener('pointermove',e=>on&&mv(e.clientX))});
// lightbox
const lb=$('#lb'),lc=$('#lc');let items=[],i=0;
const show=()=>{const it=items[i];lc.innerHTML=it.v?`<video src="${it.v}" controls autoplay playsinline></video>`:`<img src="${it.s}" alt="${it.a}">`};
const open=(arr,n)=>{items=arr;i=n;show();lb.hidden=false;$('.x',lb).focus()};
const close=()=>{lb.hidden=true;lc.innerHTML=''};
const go=d=>{i=(i+d+items.length)%items.length;show()};
const g=$$('.mas img').map(m=>({s:m.src,a:m.alt}));$$('.mas img').forEach((m,n)=>m.onclick=()=>open(g,n));
const v=$$('.vg button').map(b=>({v:b.dataset.v}));$$('.vg button').forEach((b,n)=>b.onclick=()=>open(v,n));
$('.x',lb).onclick=close;$('.pv',lb).onclick=()=>go(-1);$('.nx',lb).onclick=()=>go(1);
addEventListener('keydown',e=>{if(lb.hidden)return;e.key==='Escape'&&close();e.key==='ArrowLeft'&&go(-1);e.key==='ArrowRight'&&go(1)});
let sx=0;lb.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});lb.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-sx;Math.abs(d)>50&&go(d<0?1:-1)});
